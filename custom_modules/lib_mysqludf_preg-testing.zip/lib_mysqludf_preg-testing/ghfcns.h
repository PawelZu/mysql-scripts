/*
 *  ghfcns.h
 *  eMailGanizer
 *
 *  Created by Rich Waters on 9/3/10.
 *  Copyright 2010 GoodHumans. All rights reserved.
 *
 */

char *ghstrndup( char *s , size_t l );
void ghlogprintf(char *fmt, ...);

